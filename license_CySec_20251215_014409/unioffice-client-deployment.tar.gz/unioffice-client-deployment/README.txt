═══════════════════════════════════════════════════════════════
              UniOffice 客户端部署包
═══════════════════════════════════════════════════════════════

客户名称: CySec
创建时间: 2025-12-15 01:44:09

📦 文件清单
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

unioffice/          完整源代码（包含修改后的公钥）
client_verify.go    验证程序（已配置客户名: CySec）
go.mod              模块配置（包含 replace 指令）
README.txt          本说明文件

📋 使用步骤
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1️⃣ 将许可证文件（license.key）放到此目录

2️⃣ 安装 Go（如果没有）
   Ubuntu: sudo apt install golang-go
   CentOS: sudo yum install golang
   macOS:  brew install go

3️⃣ 下载依赖
   go mod download

4️⃣ 运行验证
   go run client_verify.go

预期输出：
   ✅ 许可证验证成功！
      客户: CySec
   ✅ 文档创建成功: output.docx

⚠️ 重要提示
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

• 不要修改 unioffice/ 目录下的任何文件
• 不要删除 go.mod 中的 replace 指令
• 许可证必须是为客户"CySec"生成的
• 确保 license.key 文件在当前目录

故障排除
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

如果遇到 "crypto/rsa: verification error":
  1. 检查 go.mod 是否包含 replace 指令
  2. 运行: go clean -modcache
  3. 运行: go mod download
  4. 重新运行: go run client_verify.go

如果遇到 "package not found":
  1. 检查 unioffice/ 目录是否完整
  2. 检查 go.mod 中的 replace 路径是否正确

═══════════════════════════════════════════════════════════════
