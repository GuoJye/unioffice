#!/bin/bash

echo "═══════════════════════════════════════════════════════════"
echo "          客户端环境快速检查"
echo "═══════════════════════════════════════════════════════════"
echo ""

errors=0

# 检查目录结构
echo "1️⃣ 检查目录结构..."
if [ -d "unioffice" ]; then
    echo "   ✅ unioffice/ 目录存在"
else
    echo "   ❌ unioffice/ 目录不存在"
    ((errors++))
fi

# 检查 go.mod
echo "2️⃣ 检查 go.mod..."
if [ -f "go.mod" ]; then
    if grep -q "replace.*unioffice" go.mod; then
        echo "   ✅ go.mod 包含 replace 指令"
    else
        echo "   ❌ go.mod 缺少 replace 指令"
        ((errors++))
    fi
else
    echo "   ❌ go.mod 不存在"
    ((errors++))
fi

# 检查许可证文件
echo "3️⃣ 检查许可证文件..."
if [ -f "license.key" ]; then
    echo "   ✅ license.key 存在"
else
    echo "   ⚠️  license.key 不存在（请先复制许可证文件）"
fi

# 检查 Go
echo "4️⃣ 检查 Go 环境..."
if command -v go &> /dev/null; then
    GO_VERSION=$(go version | awk '{print $3}')
    echo "   ✅ Go 已安装 ($GO_VERSION)"
else
    echo "   ❌ Go 未安装"
    ((errors++))
fi

echo ""
if [ $errors -eq 0 ]; then
    echo "✅ 所有检查通过！"
    if [ -f "license.key" ]; then
        echo ""
        echo "可以运行验证程序:"
        echo "  go run client_verify.go"
    else
        echo ""
        echo "下一步:"
        echo "  1. 复制 license.key 到当前目录"
        echo "  2. 运行: go run client_verify.go"
    fi
else
    echo "❌ 发现 $errors 个错误，请修复后再试"
fi
echo ""
