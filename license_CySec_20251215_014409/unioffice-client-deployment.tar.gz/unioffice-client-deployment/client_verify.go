package main

import (
	"fmt"
	"os"
	"github.com/unidoc/unioffice/v2/common/license"
	"github.com/unidoc/unioffice/v2/document"
)

func main() {
	// 读取许可证文件
	licenseContent, err := os.ReadFile("license.key")
	if err != nil {
		fmt.Printf("❌ 无法读取许可证: %v\n", err)
		return
	}

	// 验证许可证（客户名称必须与生成时一致）
	customerName := "CySec"  // ⚠️ 将被替换
	err = license.SetLicenseKey(string(licenseContent), customerName)
	if err != nil {
		fmt.Printf("❌ 许可证验证失败: %v\n", err)
		fmt.Println("\n💡 可能的原因:")
		fmt.Println("   1. 源代码中的公钥与签名密钥不匹配")
		fmt.Println("   2. go.mod 缺少 replace 指令")
		fmt.Println("   3. 客户名称不一致")
		return
	}

	fmt.Println("✅ 许可证验证成功！")
	fmt.Printf("   客户: %s\n", customerName)

	// 测试创建文档
	doc := document.New()
	para := doc.AddParagraph()
	run := para.AddRun()
	run.AddText("Hello UniOffice! 许可证验证成功！")

	err = doc.SaveToFile("output.docx")
	if err != nil {
		fmt.Printf("❌ 文档保存失败: %v\n", err)
		return
	}

	fmt.Println("✅ 文档创建成功: output.docx")
}
